=== SVGpermissions ===
Author: Nzureuz
Author URI: http://thegameadventurers.com
Plugin URI: http://thegameadventurers.com
Requires at least: 4.0
Tested up to: 4.0
Version: 1.0


== Copyright ==
Copyright 2014 - 2015 Nzureuz

This software is NOT to be distributed, but can be INCLUDED in WP themes: Premium or Contracted.
This software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.